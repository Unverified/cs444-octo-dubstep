Complier project for cs 444


Members:
Nik Illerbrun   - nillerbr
Nick Fagan      - nmfagan 
Wesley Chalmers - wwchalme 
